package com.htik.sample;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;
import lombok.ToString;

@Component
@Getter
@ToString
//@AllArgsConstructor(모든것을 받겠다.)
@RequiredArgsConstructor //(@NonNull)도 되지만 final을 사용해도 된다. 
public class Hotel {
	
	
//	@NonNull //(@NonNull 된것만 받겠다.)
	private final Chef chef;
	
	private int age;
	
//	public Hotel(Chef chef) {
//		this.chef = chef;
//	}
}
