package com.htik.sample;

import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
public class Chef {
	private String name = "이연복";
	
}
