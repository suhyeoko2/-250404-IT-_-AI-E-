package servlets;

import java.sql.Connection;
import java.sql.DriverManager;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;

public class AppInitServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		//conn 객체를 생성해서 데이터보관소 저장 
		System.out.println("AppInitServlet 준비.....");
		super.init(config);
		
		try {
			ServletContext sc = this.getServletContext();
			Class.forName(sc.getInitParameter("driver"));
			Connection conn = DriverManager.getConnection(sc.getInitParameter("url"), 
											   sc.getInitParameter("username"),
											   sc.getInitParameter("password"));
			sc.setAttribute("conn", conn);
		}catch(Exception e) {
			throw new ServletException(e);
		}
	}

	public void destroy() {
		System.out.println("AppInitServlet 마무리....");
		super.destroy();
		Connection conn = (Connection)this.getServletContext().getAttribute("conn");
		try {
			if(conn != null && conn.isClosed()== false) conn.close();
		}catch(Exception e) {}
	}

}
