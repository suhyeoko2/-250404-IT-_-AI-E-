package servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import dto.Member;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/auth/login")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//로그인 화면을 위임
		RequestDispatcher rd = request.getRequestDispatcher("/auth/LoginForm.jsp");
		rd.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//전송된 email,pwd 저장해두고
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		
		//DB에서 쿼리수행 해당하는 정보를 받아오기
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		String query = null;
		
		try {
			ServletContext sc =  this.getServletContext();
			conn = (Connection)sc.getAttribute("conn");
			query = "select * from members where email=? and pwd=?";
			
			pst = conn.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2, pwd);
			
			rs = pst.executeQuery();
			
			if(rs.next()) {   //로그인 성공 -> 목록화면 요청
				Member loginMember = new Member();
				loginMember.setMno(rs.getInt("mno"));
				loginMember.setMname(rs.getString("mname"));
				loginMember.setEmail(rs.getString("email"));
				loginMember.setPwd(rs.getString("pwd"));
				loginMember.setCre_date(rs.getDate("cre_date"));
				loginMember.setMod_date(rs.getDate("mod_date"));
				
				HttpSession session =  request.getSession();
				session.setAttribute("loginMember", loginMember);
				
				response.sendRedirect("../member/list");
			} else { 			//로그인실패 -> 실패화면 위임
				RequestDispatcher rd = request.getRequestDispatcher("/auth/LoginFail.jsp");
				rd.forward(request, response);
			}
			
		}catch(Exception e) {
			
		}finally {
			
		}
		
		
		//로그인 성공 실패를 확인
	}
}
