package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/member/add")
public class MemberAddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher rd = request.getRequestDispatcher("/member/MemberAddForm.jsp");
		rd.forward(request, response);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//화면에서 전송된 정보를 db에 저장
		//1. 전송된 정보 저장
		String mname = request.getParameter("mname");
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
	
		//2. DB 연결해서 쿼리만들어 저장후 DB 해제
		Connection conn = null;
		PreparedStatement pst = null;
		String query = null;
		
		try {
			ServletContext sc = this.getServletContext();
			//Class.forName(sc.getInitParameter("driver"));
			//conn = DriverManager.getConnection(sc.getInitParameter("url"), 
			//								   sc.getInitParameter("username"),
			//								   sc.getInitParameter("password"));
			
			conn = (Connection)sc.getAttribute("conn");
			
			query = "insert into members values (seq_members.nextval, ?,?,?,sysdate,sysdate)";
			pst = conn.prepareStatement(query);
			pst.setString(1, email);
			pst.setString(2, pwd);
			pst.setString(3, mname);
			
			pst.executeUpdate();  //DB에서는 저장
			
			response.sendRedirect("list");
			
		}catch(Exception e) {
			e.printStackTrace();
			RequestDispatcher rd = request.getRequestDispatcher("/Error.jsp");
			rd.include(request, response);
		}finally {
			try {
				if(pst != null) pst.close();
				//if(conn != null) conn.close();
			}catch(Exception e) {
				e.printStackTrace();
			}
		}
		
	}

}
