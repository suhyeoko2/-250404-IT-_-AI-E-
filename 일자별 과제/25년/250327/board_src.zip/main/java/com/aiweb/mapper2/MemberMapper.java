package com.aiweb.mapper2;

public interface MemberMapper {

}
