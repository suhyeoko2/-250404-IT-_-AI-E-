package com.aiweb.mapper;

import java.util.List;

import com.aiweb.domain.MemberVO;

public interface MemberMapper {

	public List<MemberVO> getList();	
	public void insert(MemberVO member);
	public void insertSelectKey(MemberVO member);
	public MemberVO read(long mno);
	public int delete(long bno);
	public int update(MemberVO member);	
}
