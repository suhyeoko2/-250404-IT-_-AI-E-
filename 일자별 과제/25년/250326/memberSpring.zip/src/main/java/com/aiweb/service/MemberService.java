package com.aiweb.service;

import java.util.List;

import com.aiweb.domain.MemberVO;

public interface MemberService {
	
	public void register(MemberVO member);
	public MemberVO get(long mno);
	public boolean modify(MemberVO member);
	public boolean remove(long bno);
	public List<MemberVO> getList();
}
