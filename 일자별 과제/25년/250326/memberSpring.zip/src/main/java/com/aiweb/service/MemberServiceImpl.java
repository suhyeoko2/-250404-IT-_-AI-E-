package com.aiweb.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.aiweb.domain.MemberVO;
import com.aiweb.mapper.MemberMapper;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service
@Log4j
@AllArgsConstructor
public class MemberServiceImpl implements MemberService {
	
	private MemberMapper mapper;
	
	@Override
	public void register(MemberVO member) {
		 log.info("service register....");
		 mapper.insertSelectKey(member);		
	}

	@Override
	public MemberVO get(long mno) {
		log.info("조회할 번호:" + mno);
		mapper.read(mno);
		return null;
	}

	@Override
	public boolean modify(MemberVO member) {
		log.info("수정할 번호:" + member.getMno());	
		return mapper.update(member)==1;
	}

	@Override
	public boolean remove(long mno) {
		log.info("삭제할 번호:" + mno);
		return mapper.delete(mno)==1;
	}

	@Override
	public List<MemberVO> getList(){
		log.info("......getList.....");
		return mapper.getList();		
	}
}