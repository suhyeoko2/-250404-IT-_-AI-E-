package bind;

public interface DataBinding {
	Object[] getDataBinders();
}
